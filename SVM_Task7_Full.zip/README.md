
# Task 7 - Support Vector Machines (SVM)

This task involves:
- Training SVM models using linear and RBF kernels.
- Visualizing decision boundaries.
- Hyperparameter tuning.
- Model evaluation using confusion matrix and classification report.

## Files included
- SVM_Task7_Summary.txt: Performance summary and hyperparameters.
- Confusion_Matrix.png: Confusion matrix visualization.
- svm_task7_code.py: Source code for the task.
- README.md: Description of the task and instructions.

## Tools used
- Python
- Scikit-learn
- NumPy
- Matplotlib
- Seaborn
