# Task 7: Support Vector Machines (SVM)

This project demonstrates binary classification using SVMs with both linear and RBF kernels.
The Breast Cancer dataset is used, and PCA is applied to visualize decision boundaries.

## Files:
- `svm_task.py`: Full code implementation
- `breast-cancer.csv`: Dataset
- `svm_decision_boundaries.png`: Decision boundary visualizations
- `results.txt`: Model evaluation and hyperparameter tuning results
